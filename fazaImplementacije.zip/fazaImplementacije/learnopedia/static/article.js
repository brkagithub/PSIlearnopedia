// Marko A
$(document).ready(() => {

    $('#summernote').summernote('foreColor', 'blue');

  /*categories.map((categoryName) => {
    categoriesEl.append(
      `<a href="${categoryName}.html" class="textNoDeco"><button class="rounded-circle categoryChip">${categoryName}</button></a>`
    );
  });*/

  /*authorEl.append(`<h3>profile pic</h3>
    <a href="${article.author.profileSlug}.html"> <h3 class="underlinedAuthor">${article.author.name}</h3></a>
    <p>Total likes: ${article.author.totalLikes}</p>
    <h6>From same author</h6>`);*/

  /*article.author.articles.map((article) => {
    authorEl.append(
      `<a href="${article.slug}.html"><h5>${article.title}</h5></a>`
    );
  });*/

  //title.html(article.title);

  //contentEl.append(`<div class="mt-20">${article.content}</div>`);
});
