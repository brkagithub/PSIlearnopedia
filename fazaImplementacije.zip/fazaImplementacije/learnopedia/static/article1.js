// Marko Brkic
//$(document).ready(function(){
  //$("#sadrzaj").html($("#sakriven").text());
//});
