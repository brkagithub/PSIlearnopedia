Folder for django templates. Initially, dummy data will be inserted with Jquery but those parts of code will be deleted once the Django back-end implementation is done.
